# Projet Graphes et Open Data - Analyse des GO Terms

Ce projet consiste en l'analyse d'un ensemble de GO terms (Gene Ontology) à partir d'un fichier Excel de résultats d'enrichissement GO. L'analyse comprend la création d'un graphe où les GO terms sont connectés s'ils partagent des gènes communs, la détection de communautés, le calcul de métriques de centralité et la visualisation des résultats.

## Structure du projet

- `code/` : Scripts Python utilisés pour l'analyse
- `resultats/` : Résultats de l'analyse (graphes, statistiques, visualisations)
- `captures_organisees/` : Visualisations organisées par catégorie avec interface HTML

## Étapes de l'analyse

1. **Exploration des données** : Analyse du fichier Excel GO_enrichment_results.xlsx
2. **Création du graphe** : Construction d'un graphe où les GO terms sont connectés s'ils partagent des gènes communs
3. **Analyse des communautés** : Détection de communautés avec l'algorithme de Louvain
4. **Visualisation du graphe** : Création de visualisations colorées par communauté
5. **Calcul des métriques de centralité** : Calcul de différentes mesures de centralité (degré, intermédiarité, proximité, vecteur propre, PageRank)
6. **Organisation des résultats** : Structuration des visualisations et des résultats

## Résultats principaux

- **Nombre de GO terms** : 771 GO terms dans le fichier d'origine, 731 avec des gènes associés
- **Structure du graphe** : 731 nœuds et 32355 arêtes (avec un seuil de 10 gènes partagés)
- **Communautés détectées** : 4 communautés principales
- **Modularité du graphe** : 0.1902

## Visualisation des résultats

Pour visualiser les résultats, ouvrez le fichier `captures_organisees/index.html` dans un navigateur web.

## Reproduction de l'analyse

Pour reproduire l'analyse, exécutez les scripts Python dans l'ordre suivant :
1. `create_go_graph.py` : Création du graphe des GO terms
2. `analyze_communities.py` : Analyse des communautés du graphe
3. `visualize_communities.py` : Visualisation du graphe avec les communautés
4. `calculate_centrality.py` : Calcul des métriques de centralité
5. `organize_screenshots.py` : Organisation des captures d'écran

## Auteur

Ce projet a été réalisé dans le cadre du cours "Graphes et Open Data".
