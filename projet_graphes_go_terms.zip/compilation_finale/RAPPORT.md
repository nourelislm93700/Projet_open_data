# Rapport d'analyse des GO Terms

## 1. Introduction

Ce rapport présente l'analyse d'un ensemble de GO terms (Gene Ontology) à partir d'un fichier Excel de résultats d'enrichissement GO. L'objectif est de modéliser les relations entre les GO terms sous forme de graphe, d'identifier des communautés fonctionnelles et d'analyser l'importance relative des différents GO terms dans le réseau.

## 2. Méthodologie

### 2.1 Données utilisées

Les données proviennent du fichier Excel "GO_enrichment_results.xlsx" qui contient 771 GO terms (pathways) et 4980 gènes uniques répartis sur 2121 colonnes. Chaque ligne représente un GO term et les colonnes contiennent les gènes associés à ce GO term.

### 2.2 Construction du graphe

Un graphe non orienté a été construit où :
- Les nœuds représentent les GO terms
- Une arête est créée entre deux GO terms s'ils partagent au moins 10 gènes communs
- Le poids de l'arête correspond au nombre de gènes partagés

Cette modélisation permet de représenter les relations fonctionnelles entre les GO terms basées sur le partage de gènes.

### 2.3 Détection de communautés

L'algorithme de Louvain a été utilisé pour détecter des communautés dans le graphe. Cet algorithme optimise la modularité du graphe, qui mesure la densité des connexions à l'intérieur des communautés par rapport aux connexions entre communautés.

### 2.4 Calcul des métriques de centralité

Plusieurs métriques de centralité ont été calculées pour identifier les GO terms les plus importants dans le réseau :
- Centralité de degré : nombre de connexions d'un nœud
- Centralité d'intermédiarité : fréquence à laquelle un nœud se trouve sur les plus courts chemins entre d'autres nœuds
- Centralité de proximité : proximité d'un nœud à tous les autres nœuds du réseau
- Centralité de vecteur propre : influence d'un nœud dans le réseau
- PageRank : importance d'un nœud basée sur la structure du réseau

## 3. Résultats

### 3.1 Structure du graphe

Le graphe final contient 731 nœuds (GO terms) et 32355 arêtes. Il est très dense, ce qui indique un haut niveau d'interconnexion entre les GO terms.

### 3.2 Communautés détectées

L'algorithme de Louvain a détecté 4 communautés principales :
- Communauté 3 : 213 GO terms, principalement liés à la réponse immunitaire adaptative
- Communauté 0 : 197 GO terms, principalement liés au développement et à l'homéostasie cellulaire
- Communauté 2 : 174 GO terms, principalement liés à la réponse immunitaire innée
- Communauté 1 : 112 GO terms, principalement liés à la réponse de phase aiguë et à l'autophagie

La modularité du graphe est de 0.1902, ce qui indique une structure communautaire modérée.

### 3.3 GO terms centraux

Les GO terms les plus centraux selon différentes métriques sont :
- Centralité de degré : "limbic system development" et "regulation of interleukin-12 production"
- Centralité d'intermédiarité : "regulation of interleukin-12 production" et "limbic system development"
- Centralité de proximité : "regulation of interleukin-12 production" et "limbic system development"
- Centralité de vecteur propre : "positive regulation of immune system process" et "regulation of interleukin-12 production"
- PageRank : "limbic system development" et "regulation of interleukin-12 production"

Ces GO terms jouent un rôle central dans le réseau et pourraient représenter des processus biologiques clés.

## 4. Discussion

L'analyse du graphe des GO terms a révélé une structure communautaire claire avec 4 communautés principales correspondant à différentes fonctions biologiques. Les communautés 2 et 3 sont fortement liées, ce qui suggère une relation étroite entre la réponse immunitaire innée et adaptative.

Les GO terms les plus centraux, notamment "limbic system development" et "regulation of interleukin-12 production", semblent jouer un rôle crucial dans le réseau. Leur position centrale suggère qu'ils pourraient être des régulateurs importants ou des points de convergence pour différentes voies biologiques.

La forte corrélation entre les différentes métriques de centralité indique que les GO terms importants le sont généralement selon plusieurs critères, ce qui renforce leur pertinence biologique.

## 5. Conclusion

Cette analyse a permis de modéliser efficacement les relations entre les GO terms sous forme de graphe et d'identifier des communautés fonctionnelles ainsi que des GO terms centraux. Ces résultats pourraient aider à mieux comprendre l'organisation fonctionnelle des processus biologiques représentés par ces GO terms et à identifier des cibles potentielles pour des études plus approfondies.

Les visualisations générées fournissent une représentation claire de la structure du graphe et des relations entre les GO terms, facilitant l'interprétation des résultats.
