import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
import community as community_louvain
import os
import matplotlib.cm as cm

# Chargement du graphe créé précédemment
print("Chargement du graphe des GO terms...")
G = nx.read_gexf("resultats/go_terms_graph.gexf")
print(f"Graphe chargé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")

# Chargement de la plus grande composante connexe
G_largest_cc = nx.read_gexf("resultats/go_terms_largest_cc.gexf")
print(f"Plus grande composante connexe chargée avec {G_largest_cc.number_of_nodes()} nœuds et {G_largest_cc.number_of_edges()} arêtes")

# Détection des communautés avec l'algorithme de Louvain
print("Détection des communautés avec l'algorithme de Louvain...")
partition = community_louvain.best_partition(G_largest_cc)
num_communities = len(set(partition.values()))
print(f"Nombre de communautés détectées: {num_communities}")

# Ajout des informations de communauté aux nœuds du graphe
for node, comm_id in partition.items():
    G_largest_cc.nodes[node]['community'] = comm_id

# Sauvegarde du graphe avec les informations de communauté
nx.write_gexf(G_largest_cc, "resultats/go_terms_communities.gexf")
print("Graphe avec communautés sauvegardé au format GEXF")

# Analyse des communautés
print("Analyse des communautés...")
community_nodes = defaultdict(list)
for node, data in G_largest_cc.nodes(data=True):
    comm_id = data.get('community', -1)
    community_nodes[comm_id].append(node)

# Tri des communautés par taille
sorted_communities = sorted(community_nodes.items(), key=lambda x: len(x[1]), reverse=True)

# Affichage des statistiques des communautés
print("\nStatistiques des communautés:")
print("ID | Taille | Degré moyen | Variance du degré")
print("-" * 50)

community_stats = []
for comm_id, nodes_list in sorted_communities:
    if len(nodes_list) > 5:  # Ignorer les très petites communautés
        degs = [G_largest_cc.degree(n) for n in nodes_list]
        avg_deg = np.mean(degs)
        var_deg = np.var(degs)
        community_stats.append((comm_id, len(nodes_list), avg_deg, var_deg))
        print(f"{comm_id:2d} | {len(nodes_list):6d} | {avg_deg:11.2f} | {var_deg:16.2f}")

# Sauvegarde des statistiques des communautés
with open("resultats/community_stats.txt", "w") as f:
    f.write("ID | Taille | Degré moyen | Variance du degré\n")
    f.write("-" * 50 + "\n")
    for comm_id, size, avg_deg, var_deg in community_stats:
        f.write(f"{comm_id:2d} | {size:6d} | {avg_deg:11.2f} | {var_deg:16.2f}\n")
print("Statistiques des communautés sauvegardées dans community_stats.txt")

# Analyse des termes GO dans chaque communauté
print("\nAnalyse des termes GO dans les principales communautés:")
top_communities = sorted_communities[:5]  # Analyser les 5 plus grandes communautés

with open("resultats/community_go_terms.txt", "w") as f:
    for comm_id, nodes_list in top_communities:
        print(f"\nCommunauté {comm_id} ({len(nodes_list)} GO terms):")
        f.write(f"\nCommunauté {comm_id} ({len(nodes_list)} GO terms):\n")
        
        # Afficher les 10 premiers GO terms de la communauté
        for i, node in enumerate(nodes_list[:10]):
            print(f"  - {node}")
            f.write(f"  - {node}\n")
        
        if len(nodes_list) > 10:
            print(f"  ... et {len(nodes_list) - 10} autres GO terms")
            f.write(f"  ... et {len(nodes_list) - 10} autres GO terms\n")

print("Analyse des GO terms par communauté sauvegardée dans community_go_terms.txt")

# Création d'un sous-graphe pour les communautés principales
print("\nCréation d'un sous-graphe pour les communautés principales...")
top_community_nodes = []
for comm_id, nodes_list in top_communities:
    top_community_nodes.extend(nodes_list)

G_top_communities = G_largest_cc.subgraph(top_community_nodes).copy()
print(f"Sous-graphe créé avec {G_top_communities.number_of_nodes()} nœuds et {G_top_communities.number_of_edges()} arêtes")

# Sauvegarde du sous-graphe des communautés principales
nx.write_gexf(G_top_communities, "resultats/go_terms_top_communities.gexf")
print("Sous-graphe des communautés principales sauvegardé au format GEXF")

# Analyse de la modularité
print("\nCalcul de la modularité du graphe...")
modularity = community_louvain.modularity(partition, G_largest_cc)
print(f"Modularité du graphe: {modularity:.4f}")

# Analyse des liens entre communautés
print("\nAnalyse des liens entre communautés...")
inter_community_edges = defaultdict(int)
for u, v in G_largest_cc.edges():
    comm_u = G_largest_cc.nodes[u].get('community', -1)
    comm_v = G_largest_cc.nodes[v].get('community', -1)
    if comm_u != comm_v:
        inter_community_edges[(min(comm_u, comm_v), max(comm_u, comm_v))] += 1

# Affichage des liens entre communautés
print("\nLiens entre communautés principales:")
print("Comm1 | Comm2 | Nombre de liens")
print("-" * 30)

with open("resultats/inter_community_links.txt", "w") as f:
    f.write("Comm1 | Comm2 | Nombre de liens\n")
    f.write("-" * 30 + "\n")
    
    # Filtrer pour n'afficher que les liens entre les communautés principales
    top_comm_ids = [comm_id for comm_id, _ in top_communities]
    for (comm1, comm2), num_links in sorted(inter_community_edges.items(), key=lambda x: x[1], reverse=True):
        if comm1 in top_comm_ids and comm2 in top_comm_ids:
            print(f"{comm1:5d} | {comm2:5d} | {num_links:14d}")
            f.write(f"{comm1:5d} | {comm2:5d} | {num_links:14d}\n")

print("Analyse des liens entre communautés sauvegardée dans inter_community_links.txt")

print("Analyse des communautés terminée avec succès!")
