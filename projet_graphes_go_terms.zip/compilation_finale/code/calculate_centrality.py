import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
import community as community_louvain
import os
import matplotlib.cm as cm

# Chargement du graphe avec les communautés
print("Chargement du graphe des GO terms avec communautés...")
G = nx.read_gexf("resultats/go_terms_communities.gexf")
print(f"Graphe chargé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")

# Récupération des informations de communauté
print("Récupération des informations de communauté...")
communities = {}
for node, data in G.nodes(data=True):
    comm_id = data.get('community', -1)
    if comm_id != -1:
        communities[node] = int(comm_id)

# Calcul des métriques de centralité
print("Calcul des métriques de centralité...")

# 1. Centralité de degré
print("Calcul de la centralité de degré...")
degree_centrality = nx.degree_centrality(G)
print(f"Centralité de degré calculée pour {len(degree_centrality)} nœuds")

# 2. Centralité d'intermédiarité (betweenness)
print("Calcul de la centralité d'intermédiarité...")
# Utiliser un échantillon de nœuds pour accélérer le calcul si le graphe est très grand
if G.number_of_nodes() > 1000:
    print("Graphe très grand, calcul approximatif de la centralité d'intermédiarité...")
    betweenness_centrality = nx.betweenness_centrality(G, k=100, normalized=True, seed=42)
else:
    betweenness_centrality = nx.betweenness_centrality(G, normalized=True)
print(f"Centralité d'intermédiarité calculée pour {len(betweenness_centrality)} nœuds")

# 3. Centralité de proximité (closeness)
print("Calcul de la centralité de proximité...")
closeness_centrality = nx.closeness_centrality(G)
print(f"Centralité de proximité calculée pour {len(closeness_centrality)} nœuds")

# 4. Centralité de vecteur propre (eigenvector)
print("Calcul de la centralité de vecteur propre...")
eigenvector_centrality = nx.eigenvector_centrality_numpy(G)
print(f"Centralité de vecteur propre calculée pour {len(eigenvector_centrality)} nœuds")

# 5. Centralité de PageRank
print("Calcul de la centralité de PageRank...")
pagerank = nx.pagerank(G, alpha=0.85)
print(f"Centralité de PageRank calculée pour {len(pagerank)} nœuds")

# Création d'un DataFrame pour stocker toutes les métriques
print("Création d'un DataFrame pour stocker les métriques...")
centrality_df = pd.DataFrame({
    'GO_Term': list(G.nodes()),
    'Community': [communities.get(node, -1) for node in G.nodes()],
    'Degree': [G.degree(node) for node in G.nodes()],
    'Degree_Centrality': [degree_centrality[node] for node in G.nodes()],
    'Betweenness_Centrality': [betweenness_centrality[node] for node in G.nodes()],
    'Closeness_Centrality': [closeness_centrality[node] for node in G.nodes()],
    'Eigenvector_Centrality': [eigenvector_centrality[node] for node in G.nodes()],
    'PageRank': [pagerank[node] for node in G.nodes()]
})

# Tri du DataFrame par centralité de degré décroissante
centrality_df = centrality_df.sort_values('Degree_Centrality', ascending=False)

# Sauvegarde des métriques de centralité dans un fichier CSV
centrality_df.to_csv("resultats/centrality_metrics.csv", index=False)
print("Métriques de centralité sauvegardées dans centrality_metrics.csv")

# Affichage des 20 GO terms les plus centraux selon différentes métriques
print("\nTop 20 GO terms par centralité de degré:")
print(centrality_df[['GO_Term', 'Community', 'Degree', 'Degree_Centrality']].head(20))

print("\nTop 20 GO terms par centralité d'intermédiarité:")
print(centrality_df.sort_values('Betweenness_Centrality', ascending=False)[['GO_Term', 'Community', 'Betweenness_Centrality']].head(20))

print("\nTop 20 GO terms par centralité de proximité:")
print(centrality_df.sort_values('Closeness_Centrality', ascending=False)[['GO_Term', 'Community', 'Closeness_Centrality']].head(20))

print("\nTop 20 GO terms par centralité de vecteur propre:")
print(centrality_df.sort_values('Eigenvector_Centrality', ascending=False)[['GO_Term', 'Community', 'Eigenvector_Centrality']].head(20))

print("\nTop 20 GO terms par PageRank:")
print(centrality_df.sort_values('PageRank', ascending=False)[['GO_Term', 'Community', 'PageRank']].head(20))

# Sauvegarde des top GO terms dans un fichier texte
with open("resultats/top_central_go_terms.txt", "w") as f:
    f.write("Top 20 GO terms par centralité de degré:\n")
    f.write(centrality_df[['GO_Term', 'Community', 'Degree', 'Degree_Centrality']].head(20).to_string(index=False))
    
    f.write("\n\nTop 20 GO terms par centralité d'intermédiarité:\n")
    f.write(centrality_df.sort_values('Betweenness_Centrality', ascending=False)[['GO_Term', 'Community', 'Betweenness_Centrality']].head(20).to_string(index=False))
    
    f.write("\n\nTop 20 GO terms par centralité de proximité:\n")
    f.write(centrality_df.sort_values('Closeness_Centrality', ascending=False)[['GO_Term', 'Community', 'Closeness_Centrality']].head(20).to_string(index=False))
    
    f.write("\n\nTop 20 GO terms par centralité de vecteur propre:\n")
    f.write(centrality_df.sort_values('Eigenvector_Centrality', ascending=False)[['GO_Term', 'Community', 'Eigenvector_Centrality']].head(20).to_string(index=False))
    
    f.write("\n\nTop 20 GO terms par PageRank:\n")
    f.write(centrality_df.sort_values('PageRank', ascending=False)[['GO_Term', 'Community', 'PageRank']].head(20).to_string(index=False))

print("Top GO terms sauvegardés dans top_central_go_terms.txt")

# Visualisation des métriques de centralité
print("Création de visualisations pour les métriques de centralité...")

# Fonction pour visualiser une métrique de centralité
def visualize_centrality(centrality_metric, metric_name, cmap='viridis'):
    plt.figure(figsize=(16, 16))
    
    # Normaliser les valeurs de centralité pour la taille des nœuds
    node_sizes = [100 + 1000 * centrality_metric[node] / max(centrality_metric.values()) for node in G.nodes()]
    
    # Obtenir les couleurs des communautés
    colors = cm.rainbow(np.linspace(0, 1, len(set(communities.values()))))
    community_colors = {i: colors[i] for i in range(len(set(communities.values())))}
    node_colors = [community_colors[communities.get(node, 0)] for node in G.nodes()]
    
    # Calculer le layout (utiliser le même pour toutes les visualisations)
    pos = nx.spring_layout(G, seed=42)
    
    # Dessiner les arêtes
    nx.draw_networkx_edges(G, pos, alpha=0.2, width=0.5)
    
    # Dessiner les nœuds avec taille proportionnelle à la centralité
    nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, alpha=0.8)
    
    # Étiqueter les 10 nœuds les plus centraux
    top_nodes = sorted(centrality_metric.items(), key=lambda x: x[1], reverse=True)[:10]
    node_labels = {node: node for node, _ in top_nodes}
    nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=8, font_weight='bold')
    
    plt.title(f"Graphe des GO terms - {metric_name}")
    plt.axis('off')
    plt.savefig(f"resultats/go_terms_{metric_name.lower().replace(' ', '_')}.png", dpi=300, bbox_inches='tight')
    print(f"Visualisation de {metric_name} sauvegardée")

# Visualiser chaque métrique de centralité
visualize_centrality(degree_centrality, "Centralité de Degré")
visualize_centrality(betweenness_centrality, "Centralité d'Intermédiarité")
visualize_centrality(closeness_centrality, "Centralité de Proximité")
visualize_centrality(eigenvector_centrality, "Centralité de Vecteur Propre")
visualize_centrality(pagerank, "PageRank")

# Analyse de la corrélation entre les différentes métriques de centralité
print("Analyse de la corrélation entre les métriques de centralité...")
correlation_matrix = centrality_df[['Degree_Centrality', 'Betweenness_Centrality', 
                                   'Closeness_Centrality', 'Eigenvector_Centrality', 'PageRank']].corr()

plt.figure(figsize=(10, 8))
plt.imshow(correlation_matrix, cmap='coolwarm', vmin=-1, vmax=1)
plt.colorbar()
plt.xticks(range(len(correlation_matrix.columns)), correlation_matrix.columns, rotation=45)
plt.yticks(range(len(correlation_matrix.columns)), correlation_matrix.columns)

# Ajouter les valeurs dans les cellules
for i in range(len(correlation_matrix.columns)):
    for j in range(len(correlation_matrix.columns)):
        plt.text(j, i, f"{correlation_matrix.iloc[i, j]:.2f}", ha='center', va='center', 
                color='black' if abs(correlation_matrix.iloc[i, j]) < 0.7 else 'white')

plt.title("Matrice de corrélation des métriques de centralité")
plt.tight_layout()
plt.savefig("resultats/centrality_correlation_matrix.png", dpi=300)
print("Matrice de corrélation sauvegardée")

# Analyse des métriques de centralité par communauté
print("Analyse des métriques de centralité par communauté...")
community_centrality = centrality_df.groupby('Community').agg({
    'Degree_Centrality': ['mean', 'std', 'max'],
    'Betweenness_Centrality': ['mean', 'std', 'max'],
    'Closeness_Centrality': ['mean', 'std', 'max'],
    'Eigenvector_Centrality': ['mean', 'std', 'max'],
    'PageRank': ['mean', 'std', 'max']
})

# Sauvegarde des statistiques de centralité par communauté
community_centrality.to_csv("resultats/community_centrality_stats.csv")
print("Statistiques de centralité par communauté sauvegardées dans community_centrality_stats.csv")

print("Calcul des métriques de centralité terminé avec succès!")
