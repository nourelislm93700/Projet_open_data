import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
import community as community_louvain
import os

# Création du dossier pour les résultats
os.makedirs('resultats', exist_ok=True)

# Chargement des données
print("Chargement des données GO enrichment...")
df = pd.read_excel('/home/ubuntu/upload/GO_enrichment_results.xlsx')
print(f"Données chargées: {df.shape[0]} GO terms et {df.shape[1]-1} colonnes de gènes")

# Fonction pour obtenir l'ensemble des gènes pour chaque GO term
def get_genes_for_pathway(row):
    genes = set()
    for col in row.index[1:]:  # Ignorer la colonne 'Pathway'
        if pd.notna(row[col]):
            genes.add(row[col])
    return genes

# Création d'un dictionnaire pour stocker les gènes associés à chaque GO term
print("Extraction des gènes pour chaque GO term...")
pathway_genes = {}
for idx, row in df.iterrows():
    pathway = row['Pathway']
    genes = get_genes_for_pathway(row)
    pathway_genes[pathway] = genes

print(f"Nombre de GO terms avec des gènes associés: {len(pathway_genes)}")

# Création du graphe
print("Création du graphe des GO terms...")
G = nx.Graph()

# Ajout des nœuds (GO terms)
for pathway in pathway_genes.keys():
    G.add_node(pathway)

# Calcul du seuil pour les arêtes (nombre minimum de gènes partagés)
# On peut ajuster ce seuil selon la densité souhaitée du graphe
min_shared_genes = 5  # Seuil initial

# Ajout des arêtes entre les GO terms qui partagent des gènes
print("Ajout des arêtes entre les GO terms partageant au moins", min_shared_genes, "gènes...")
edges_added = 0
for i, (pathway1, genes1) in enumerate(pathway_genes.items()):
    for pathway2, genes2 in list(pathway_genes.items())[i+1:]:
        shared_genes = genes1.intersection(genes2)
        if len(shared_genes) >= min_shared_genes:
            weight = len(shared_genes)
            G.add_edge(pathway1, pathway2, weight=weight)
            edges_added += 1

print(f"Graphe créé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")

# Si le graphe est trop dense ou trop sparse, ajuster le seuil
if G.number_of_edges() < 100:
    print("Le graphe est trop sparse, réduction du seuil...")
    G = nx.Graph()
    for pathway in pathway_genes.keys():
        G.add_node(pathway)
    
    min_shared_genes = 3  # Réduire le seuil
    edges_added = 0
    for i, (pathway1, genes1) in enumerate(pathway_genes.items()):
        for pathway2, genes2 in list(pathway_genes.items())[i+1:]:
            shared_genes = genes1.intersection(genes2)
            if len(shared_genes) >= min_shared_genes:
                weight = len(shared_genes)
                G.add_edge(pathway1, pathway2, weight=weight)
                edges_added += 1
    
    print(f"Graphe recréé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")
elif G.number_of_edges() > 10000:
    print("Le graphe est trop dense, augmentation du seuil...")
    G = nx.Graph()
    for pathway in pathway_genes.keys():
        G.add_node(pathway)
    
    min_shared_genes = 10  # Augmenter le seuil
    edges_added = 0
    for i, (pathway1, genes1) in enumerate(pathway_genes.items()):
        for pathway2, genes2 in list(pathway_genes.items())[i+1:]:
            shared_genes = genes1.intersection(genes2)
            if len(shared_genes) >= min_shared_genes:
                weight = len(shared_genes)
                G.add_edge(pathway1, pathway2, weight=weight)
                edges_added += 1
    
    print(f"Graphe recréé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")

# Sauvegarde du graphe au format GEXF pour Gephi
nx.write_gexf(G, "resultats/go_terms_graph.gexf")
print("Graphe sauvegardé au format GEXF pour Gephi")

# Visualisation basique du graphe
plt.figure(figsize=(12, 12))
print("Création d'une visualisation basique du graphe...")
pos = nx.spring_layout(G, seed=42)  # Utiliser un seed fixe pour la reproductibilité
nx.draw(G, pos, node_size=50, node_color='lightblue', edge_color='gray', 
        with_labels=False, width=[G[u][v]['weight']/10 for u, v in G.edges()])
plt.title(f"Graphe des GO terms (seuil: {min_shared_genes} gènes partagés)")
plt.savefig("resultats/go_terms_graph_basic.png", dpi=300)
print("Visualisation basique sauvegardée")

# Détection des composantes connexes
print("Analyse des composantes connexes...")
connected_components = list(nx.connected_components(G))
print(f"Nombre de composantes connexes: {len(connected_components)}")
print(f"Taille de la plus grande composante connexe: {len(max(connected_components, key=len))}")

# Extraction de la plus grande composante connexe
largest_cc = max(connected_components, key=len)
G_largest_cc = G.subgraph(largest_cc).copy()
print(f"Plus grande composante connexe: {G_largest_cc.number_of_nodes()} nœuds et {G_largest_cc.number_of_edges()} arêtes")

# Sauvegarde de la plus grande composante connexe
nx.write_gexf(G_largest_cc, "resultats/go_terms_largest_cc.gexf")
print("Plus grande composante connexe sauvegardée au format GEXF")

# Visualisation de la plus grande composante connexe
plt.figure(figsize=(12, 12))
print("Création d'une visualisation de la plus grande composante connexe...")
pos_cc = nx.spring_layout(G_largest_cc, seed=42)
nx.draw(G_largest_cc, pos_cc, node_size=50, node_color='lightblue', edge_color='gray', 
        with_labels=False, width=[G_largest_cc[u][v]['weight']/10 for u, v in G_largest_cc.edges()])
plt.title("Plus grande composante connexe du graphe des GO terms")
plt.savefig("resultats/go_terms_largest_cc.png", dpi=300)
print("Visualisation de la plus grande composante connexe sauvegardée")

print("Création du graphe des GO terms terminée avec succès!")
