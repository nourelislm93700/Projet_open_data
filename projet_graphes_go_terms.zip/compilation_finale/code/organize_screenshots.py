import os
import shutil
from PIL import Image
import matplotlib.pyplot as plt

# Création d'un dossier pour les captures d'écran organisées
os.makedirs('resultats/captures_organisees', exist_ok=True)

# Liste des visualisations importantes à inclure dans la présentation
visualisations = [
    {
        'fichier': 'go_terms_communities_visualization.png',
        'description': 'Graphe des GO terms coloré par communauté',
        'categorie': '1_vue_globale'
    },
    {
        'fichier': 'go_terms_separate_communities.png',
        'description': 'Visualisation séparée des 4 communautés principales',
        'categorie': '2_communautes'
    },
    {
        'fichier': 'community_links_graph.png',
        'description': 'Graphe des liens entre communautés',
        'categorie': '2_communautes'
    },
    {
        'fichier': 'go_terms_centralité_de_degré.png',
        'description': 'Centralité de degré des GO terms',
        'categorie': '3_centralite'
    },
    {
        'fichier': 'go_terms_centralité_d\'intermédiarité.png',
        'description': 'Centralité d\'intermédiarité des GO terms',
        'categorie': '3_centralite'
    },
    {
        'fichier': 'go_terms_pagerank.png',
        'description': 'PageRank des GO terms',
        'categorie': '3_centralite'
    },
    {
        'fichier': 'centrality_correlation_matrix.png',
        'description': 'Matrice de corrélation des métriques de centralité',
        'categorie': '3_centralite'
    },
    {
        'fichier': 'go_terms_labeled_communities.png',
        'description': 'Graphe avec étiquettes pour les nœuds importants',
        'categorie': '4_noeuds_importants'
    },
    {
        'fichier': 'go_terms_sized_by_degree.png',
        'description': 'Graphe avec taille des nœuds proportionnelle au degré',
        'categorie': '4_noeuds_importants'
    }
]

# Création des sous-dossiers par catégorie
categories = set([v['categorie'] for v in visualisations])
for categorie in categories:
    os.makedirs(f'resultats/captures_organisees/{categorie}', exist_ok=True)

# Copie et organisation des visualisations
for viz in visualisations:
    source = f"resultats/{viz['fichier']}"
    destination = f"resultats/captures_organisees/{viz['categorie']}/{viz['fichier']}"
    shutil.copy(source, destination)
    print(f"Copié {viz['fichier']} vers {destination}")

# Création d'un fichier HTML pour visualiser les captures d'écran
html_content = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Visualisations du Graphe des GO Terms</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #2c3e50; }
        h2 { color: #3498db; margin-top: 30px; }
        .image-container { margin: 20px 0; }
        img { max-width: 100%; border: 1px solid #ddd; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .description { margin: 10px 0; font-style: italic; color: #555; }
    </style>
</head>
<body>
    <h1>Visualisations du Graphe des GO Terms</h1>
"""

# Ajout des sections par catégorie
categories_noms = {
    '1_vue_globale': 'Vue Globale du Graphe',
    '2_communautes': 'Analyse des Communautés',
    '3_centralite': 'Métriques de Centralité',
    '4_noeuds_importants': 'Nœuds Importants du Graphe'
}

for categorie in sorted(categories):
    html_content += f"\n    <h2>{categories_noms[categorie]}</h2>\n"
    
    # Filtrer les visualisations pour cette catégorie
    cat_viz = [v for v in visualisations if v['categorie'] == categorie]
    
    for viz in cat_viz:
        html_content += f"""
    <div class="image-container">
        <div class="description">{viz['description']}</div>
        <img src="../{viz['categorie']}/{viz['fichier']}" alt="{viz['description']}">
    </div>
"""

html_content += """
</body>
</html>
"""

# Écriture du fichier HTML
with open('resultats/captures_organisees/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Fichier HTML de visualisation créé: resultats/captures_organisees/index.html")

# Création d'un fichier README pour expliquer les visualisations
readme_content = """# Visualisations du Graphe des GO Terms

Ce dossier contient les visualisations générées à partir de l'analyse du graphe des GO terms.

## Organisation des visualisations

Les visualisations sont organisées en quatre catégories:

1. **Vue Globale du Graphe**: Visualisation générale du graphe des GO terms
2. **Analyse des Communautés**: Visualisations des communautés détectées et de leurs relations
3. **Métriques de Centralité**: Visualisations des différentes métriques de centralité calculées
4. **Nœuds Importants du Graphe**: Visualisations mettant en évidence les nœuds importants du graphe

## Visualisation Web

Pour une meilleure expérience de visualisation, ouvrez le fichier `index.html` dans un navigateur web.

## Description des visualisations

"""

# Ajout des descriptions des visualisations
for viz in visualisations:
    readme_content += f"- **{viz['fichier']}**: {viz['description']}\n"

# Écriture du fichier README
with open('resultats/captures_organisees/README.md', 'w', encoding='utf-8') as f:
    f.write(readme_content)

print("Fichier README créé: resultats/captures_organisees/README.md")

print("Organisation des captures d'écran terminée avec succès!")
