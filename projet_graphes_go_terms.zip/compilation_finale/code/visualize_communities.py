import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from collections import defaultdict
import community as community_louvain
import os
import matplotlib.cm as cm

# Chargement du graphe avec les communautés
print("Chargement du graphe des GO terms avec communautés...")
G = nx.read_gexf("resultats/go_terms_communities.gexf")
print(f"Graphe chargé avec {G.number_of_nodes()} nœuds et {G.number_of_edges()} arêtes")

# Récupération des informations de communauté
print("Récupération des informations de communauté...")
communities = {}
for node, data in G.nodes(data=True):
    comm_id = data.get('community', -1)
    if comm_id != -1:
        communities[node] = int(comm_id)

# Vérification du nombre de communautés
num_communities = len(set(communities.values()))
print(f"Nombre de communautés: {num_communities}")

# Création d'une palette de couleurs pour les communautés
colors = cm.rainbow(np.linspace(0, 1, num_communities))
community_colors = {i: colors[i] for i in range(num_communities)}

# Préparation des couleurs des nœuds
node_colors = []
for node in G.nodes():
    comm_id = communities.get(node, -1)
    if comm_id != -1:
        node_colors.append(community_colors[comm_id])
    else:
        node_colors.append('gray')  # Couleur par défaut pour les nœuds sans communauté

# Visualisation du graphe avec les communautés
print("Création de la visualisation du graphe avec communautés...")
plt.figure(figsize=(16, 16))
pos = nx.spring_layout(G, seed=42)  # Utiliser un seed fixe pour la reproductibilité

# Dessiner les arêtes
nx.draw_networkx_edges(G, pos, alpha=0.2, width=0.5)

# Dessiner les nœuds avec les couleurs des communautés
nx.draw_networkx_nodes(G, pos, node_size=50, node_color=node_colors, alpha=0.8)

plt.title("Graphe des GO terms coloré par communauté")
plt.axis('off')
plt.savefig("resultats/go_terms_communities_visualization.png", dpi=300, bbox_inches='tight')
print("Visualisation du graphe avec communautés sauvegardée")

# Visualisation des communautés séparément
print("Création de visualisations séparées pour chaque communauté...")
community_nodes = defaultdict(list)
for node, comm_id in communities.items():
    community_nodes[comm_id].append(node)

# Tri des communautés par taille
sorted_communities = sorted(community_nodes.items(), key=lambda x: len(x[1]), reverse=True)

# Visualisation des 4 plus grandes communautés
plt.figure(figsize=(20, 20))
for i, (comm_id, nodes) in enumerate(sorted_communities[:4]):
    plt.subplot(2, 2, i+1)
    
    # Créer un sous-graphe pour cette communauté
    subgraph = G.subgraph(nodes)
    
    # Calculer le layout pour ce sous-graphe
    sub_pos = nx.spring_layout(subgraph, seed=42)
    
    # Dessiner le sous-graphe
    nx.draw_networkx(subgraph, sub_pos, node_size=30, 
                    node_color=[community_colors[comm_id]]*len(nodes),
                    with_labels=False, alpha=0.8, width=0.5)
    
    plt.title(f"Communauté {comm_id} ({len(nodes)} GO terms)")
    plt.axis('off')

plt.tight_layout()
plt.savefig("resultats/go_terms_separate_communities.png", dpi=300, bbox_inches='tight')
print("Visualisations séparées des communautés sauvegardées")

# Visualisation du graphe avec étiquettes pour les nœuds importants
print("Création d'une visualisation avec étiquettes pour les nœuds importants...")
plt.figure(figsize=(16, 16))

# Dessiner les arêtes
nx.draw_networkx_edges(G, pos, alpha=0.2, width=0.5)

# Dessiner les nœuds avec les couleurs des communautés
nx.draw_networkx_nodes(G, pos, node_size=50, node_color=node_colors, alpha=0.8)

# Identifier les nœuds importants (par exemple, les 5 nœuds avec le plus haut degré dans chaque communauté)
important_nodes = []
for comm_id, nodes in sorted_communities[:4]:
    # Calculer le degré de chaque nœud dans cette communauté
    node_degrees = [(node, G.degree(node)) for node in nodes]
    # Trier par degré décroissant et prendre les 5 premiers
    top_nodes = sorted(node_degrees, key=lambda x: x[1], reverse=True)[:5]
    important_nodes.extend([node for node, _ in top_nodes])

# Dessiner les étiquettes uniquement pour les nœuds importants
node_labels = {node: node for node in important_nodes}
nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=8, font_weight='bold')

plt.title("Graphe des GO terms avec étiquettes pour les nœuds importants")
plt.axis('off')
plt.savefig("resultats/go_terms_labeled_communities.png", dpi=300, bbox_inches='tight')
print("Visualisation avec étiquettes sauvegardée")

# Visualisation du graphe avec la taille des nœuds proportionnelle à leur degré
print("Création d'une visualisation avec taille des nœuds proportionnelle au degré...")
plt.figure(figsize=(16, 16))

# Calculer le degré de chaque nœud
node_degrees = dict(G.degree())
# Normaliser les tailles des nœuds
node_sizes = [20 + 100 * (node_degrees[node] / max(node_degrees.values())) for node in G.nodes()]

# Dessiner les arêtes
nx.draw_networkx_edges(G, pos, alpha=0.2, width=0.5)

# Dessiner les nœuds avec les couleurs des communautés et tailles proportionnelles au degré
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, alpha=0.8)

plt.title("Graphe des GO terms avec taille des nœuds proportionnelle au degré")
plt.axis('off')
plt.savefig("resultats/go_terms_sized_by_degree.png", dpi=300, bbox_inches='tight')
print("Visualisation avec taille proportionnelle au degré sauvegardée")

# Visualisation des liens entre communautés
print("Création d'une visualisation des liens entre communautés...")
plt.figure(figsize=(12, 12))

# Créer un graphe des communautés
community_graph = nx.Graph()
for comm_id in set(communities.values()):
    community_graph.add_node(comm_id, size=len(community_nodes[comm_id]))

# Ajouter les arêtes entre communautés
for u, v in G.edges():
    comm_u = communities.get(u, -1)
    comm_v = communities.get(v, -1)
    if comm_u != comm_v and comm_u != -1 and comm_v != -1:
        if community_graph.has_edge(comm_u, comm_v):
            community_graph[comm_u][comm_v]['weight'] += 1
        else:
            community_graph.add_edge(comm_u, comm_v, weight=1)

# Calculer le layout pour le graphe des communautés
comm_pos = nx.spring_layout(community_graph, seed=42)

# Dessiner les nœuds avec taille proportionnelle au nombre de GO terms
node_sizes = [1000 * (community_graph.nodes[comm_id]['size'] / max([data['size'] for _, data in community_graph.nodes(data=True)])) for comm_id in community_graph.nodes()]

# Dessiner les arêtes avec épaisseur proportionnelle au nombre de liens
edge_widths = [0.1 * community_graph[u][v]['weight'] / max([data['weight'] for _, _, data in community_graph.edges(data=True)]) for u, v in community_graph.edges()]

# Dessiner le graphe des communautés
nx.draw_networkx_nodes(community_graph, comm_pos, node_size=node_sizes, 
                      node_color=[community_colors[comm_id] for comm_id in community_graph.nodes()],
                      alpha=0.8)
nx.draw_networkx_edges(community_graph, comm_pos, width=edge_widths, alpha=0.6)
nx.draw_networkx_labels(community_graph, comm_pos, labels={comm_id: f"Comm {comm_id}" for comm_id in community_graph.nodes()},
                       font_size=12, font_weight='bold')

plt.title("Graphe des liens entre communautés")
plt.axis('off')
plt.savefig("resultats/community_links_graph.png", dpi=300, bbox_inches='tight')
print("Visualisation des liens entre communautés sauvegardée")

print("Visualisation du graphe avec communautés terminée avec succès!")
