# Visualisations du Graphe des GO Terms

Ce dossier contient les visualisations générées à partir de l'analyse du graphe des GO terms.

## Organisation des visualisations

Les visualisations sont organisées en quatre catégories:

1. **Vue Globale du Graphe**: Visualisation générale du graphe des GO terms
2. **Analyse des Communautés**: Visualisations des communautés détectées et de leurs relations
3. **Métriques de Centralité**: Visualisations des différentes métriques de centralité calculées
4. **Nœuds Importants du Graphe**: Visualisations mettant en évidence les nœuds importants du graphe

## Visualisation Web

Pour une meilleure expérience de visualisation, ouvrez le fichier `index.html` dans un navigateur web.

## Description des visualisations

- **go_terms_communities_visualization.png**: Graphe des GO terms coloré par communauté
- **go_terms_separate_communities.png**: Visualisation séparée des 4 communautés principales
- **community_links_graph.png**: Graphe des liens entre communautés
- **go_terms_centralité_de_degré.png**: Centralité de degré des GO terms
- **go_terms_centralité_d'intermédiarité.png**: Centralité d'intermédiarité des GO terms
- **go_terms_pagerank.png**: PageRank des GO terms
- **centrality_correlation_matrix.png**: Matrice de corrélation des métriques de centralité
- **go_terms_labeled_communities.png**: Graphe avec étiquettes pour les nœuds importants
- **go_terms_sized_by_degree.png**: Graphe avec taille des nœuds proportionnelle au degré
